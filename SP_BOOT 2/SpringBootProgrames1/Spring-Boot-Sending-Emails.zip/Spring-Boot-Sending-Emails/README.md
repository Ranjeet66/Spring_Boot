# Spring-Boot-Sending-Emails-using-SMTP
Sending Emails using from Spring Boot Application using Gmail SMTP

Web tutorials:

https://www.onlinetutorialspoint.com/spring-boot/how-to-send-spring-boot-mail-example.html
