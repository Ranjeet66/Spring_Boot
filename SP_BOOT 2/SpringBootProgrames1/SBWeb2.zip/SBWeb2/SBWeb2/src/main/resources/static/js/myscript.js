function myfunc()
{
	alert("Yes it's Okay");
	return;
}